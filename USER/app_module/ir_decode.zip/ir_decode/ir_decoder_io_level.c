#include "ir_decoder_io_level.h"
#include "ir.h"
#include "util_queue_interface.h"
/// @file ir_decoder_dock.c
/// @brief ??????????????


static remote_decode_t dock_decode[IR_POSITION_MAX];
//static remote_decode_t remote_decode[IR_POSITION_MAX];

///???????IO???????��??????8??
static uint8_t ir_rx_buffer[IR_POSITION_MAX][IR_QUEUE_LEN] = {0};

///?????????????
static util_queue_t ir_rx_queue[IR_POSITION_MAX] = {0};

///?????????IO???,??8bit???????
static uint8_t ir_working_byte[IR_POSITION_MAX];

///???IO????????
static uint8_t ir_capture_counter[IR_POSITION_MAX];



void ir_rx_q_put(uint8_t index, uint8_t value)
{
    queue_put(&ir_rx_queue[index],value);
}

uint8_t ir_rx_q_get(uint8_t index)
{
    return queue_get(&ir_rx_queue[index]);
	
}

uint8_t ir_rx_q_check_is_empty(uint8_t index)
{
    return queue_is_empty(&ir_rx_queue[index]);
}

uint8_t ir_rx_q_check_is_full(uint8_t index)
{
    return queue_is_full(&ir_rx_queue[index]);
}

uint16_t ir_rx_q_get_datalength(uint8_t index)
{
    return queue_get_datalength(&ir_rx_queue[index]);
}


static void ir_dock_resync_init(remote_decode_t * decode_p)
{
    decode_p->state = REMOTE_RESYNC;
    decode_p->timer = 0;
	decode_p->count = 0; 
	decode_p->decode_value = 0;
	decode_p->ucode[0] = 0;
	decode_p->ucode_index = 0;
}


/**
 * @fn uint16_t ir_dock_decode_init(uint16_t)
 * @brief ???????????
 *
 * @param instance ?????ID
 */
static void ir_dock_decode_init(uint16_t instance)
{
    if (instance >= IR_POSITION_MAX)
    {
        return;
    }
    ir_dock_resync_init(&dock_decode[instance]);
}


//#if(ENCODED_TYPE == ENCODED_TYPE_I)
/**
 * @fn int16_t ir_dock_decode_state(uint16_t, uint16_t)
 * @brief ????????????????????????,
 * ??????????????"1"?????????3ms,????????1ms; "0"?????????1ms,????????3ms
 *
 * @param instance ?????ID
 * @param ir_state ??????????????
 * @return -1:��??????????? 0:???????????
 */

static int16_t ir_dock_decode_state(uint16_t ir_pos, uint16_t ir_state)
{
    remote_decode_t * decode_p;
    int16_t remoteStatus = -1;   
    if (ir_pos >= IR_POSITION_MAX)
    {
        return (-1);
    }
    decode_p = &dock_decode[ir_pos];
    decode_p->timer++;
    switch (decode_p->state)
    {
    case REMOTE_RESYNC: //????????		
		if(ir_state == 0)
		{
			ir_dock_resync_init(decode_p);
		}
		else if(decode_p->timer > DOCK_RESYNC_TICKS)//
		{
			decode_p->state = REMOTE_HEADER;
		}							
        break;

    case REMOTE_HEADER:
			if(ir_state == 0)
			{
				decode_p->count ++; //low 
           		if(decode_p->count >= DOCK_HEADER_LOW)
				{
					decode_p->state = REMOTE_DATA_BIT_HIGH;
					decode_p->timer = 0;
					decode_p->count = 0;
					decode_p->ucode_index = 0;
				}						 
			}
        break;				
	//????????????			
    case REMOTE_DATA_BIT_HIGH:
		{
		    if(decode_p->count == 0 && ir_state == 1) //first high level
			{
				decode_p->timer = 1;					
			}
			if(ir_state == 1)
			{
				decode_p->count ++;
			}
			// 	if (decode_p->timer > DOCK_DATA_BIT_OVER_TICK) // error code...
        	// {
            // 	ir_dock_resync_init(decode_p);
            // 	break;
        	// }
			// if ((decode_p->timer >= DOCK_DATA_BIT_UNIT_TICK) && (decode_p->count < DOCK_DATA_BIT_UNIT_TICK/2)) //error because high level too few
			// {
			// 	ir_dock_resync_init(decode_p);
            // 	break;
			// }
			if(decode_p->timer >= DOCK_DATA_BIT_UNIT_TICK-1 ) //decode_p->timer > DOCK_DATA_BIT_UNIT_TICK && ir_state == 0
			{
				decode_p->state = REMOTE_DATA_BIT_LOW;
				decode_p->timer = 0;
				decode_p->count = 0;
			}			
						
		   }
			 break;
			 
		case REMOTE_DATA_BIT_LOW:
		{
			if(decode_p->count == 0 && ir_state == 0) //first low level
			{
				decode_p->timer = 1;					
			}
			if(ir_state == 0)
			{
				decode_p->count ++;
			}
			if ((decode_p->timer >= DOCK_DATA_BIT_UNIT_TICK) && (decode_p->count < DOCK_DATA_BIT_UNIT_TICK/2)) //error because low level too few
			{
				debug_printf("%d-%d\n",decode_p->timer,decode_p->count);
				ir_dock_resync_init(decode_p);
				
            	break;
			}
			if(decode_p->timer > 10 && ir_state == 1 ) //receive high level again, one bit finish
			{
				decode_p->decode_value <<= 1;
           		if (decode_p->count >= DOCK_DATA_BIT_VALUE_1_TICK)        
				{
               		decode_p->decode_value++;
           		}
					 
				decode_p->bits_count ++;
				decode_p->state = REMOTE_DATA_BIT_HIGH; //to decode next bit
				decode_p->count = 0;
				decode_p->timer = 0;
					 
				if(decode_p->bits_count >=8) //1 byte finish
				{
					decode_p->bits_count = 0;
					decode_p->ucode[decode_p->ucode_index] = decode_p->decode_value;
					decode_p->ucode_index ++;
					if(decode_p->ucode_index > 2) //finish user code decode
					{
						if(decode_p->ucode[0] + decode_p->ucode[1] == decode_p->ucode[2]) //checksum ok
						{
							decode_p->state = REMOTE_END;
							debug_printf("decode value right: %x - %x -%x \n", decode_p->ucode[0], decode_p->ucode[1], decode_p->ucode[2]);
							remoteStatus = 0;
						}
						else 
						{
							debug_printf("decode value wrong: %x- %x -%x \n", decode_p->ucode[0], decode_p->ucode[1], decode_p->ucode[2]);
							ir_dock_resync_init(decode_p);
							break;
						}
					}
				}
			}
		}	
		break;
		
    case REMOTE_END:	
    	if(ir_state == 1)
      	{
			decode_p->count ++;
		}
        if(decode_p->timer >= DOCK_END_HIGH)
    	{
			if(decode_p->count < DOCK_END_HIGH/2) //error code too many
			{
				ir_dock_resync_init(decode_p);
            	break;
			}
			if(ir_state == 0) //end code finish
			{
				ir_dock_resync_init(decode_p);
			}
		}		
      	break;
			
    default:
        break;
    }

    return (remoteStatus);
}

/**
 * @fn uint8_t ir_decoder_dock_io_level_process(IR_REMOT_POSITION_E, uint8_t, uint8_t*)
 * @brief ???????????????��???
 *
 * @param ir_pos        ???????????
 * @param bit_state_8   8��????????8????????
 * @param code_result   ???????
 * @return 1 ??????????0 ��?????????
 */
//uint8_t adc[IR_POSITION_MAX]={0};
uint8_t ir_decoder_dock_io_level_process(IR_REMOT_POSITION_E ir_pos, uint8_t bit_state_8, uint16_t * code_result)
{
    uint8_t state = 0;
    uint8_t index = ir_pos;
    int16_t result;
    
    for (u8 i = 0; i < 8; i++)
    {
        state = (bit_state_8 >> (7 - i)) & 0x01;		
        /*????????????????,?????????????????????????,??????????*/
        result = ir_dock_decode_state(index, state);
        if ((result == 0) && (dock_decode[index].ucode[0] != 0)) //dock_decode[index].decode_value
        {
			// adc[index]= dock_decode[index].decode_value;
            //???????????
						dock_decode[index].decode_value=0;
            *code_result = dock_decode[index].ucode[0] << 8 | dock_decode[index].ucode[1]; //dock_decode[index].decode_value
            return 1;
        }
    }
    return 0;
}


/**
 * @fn void ir_detect_capture(void)
 * @brief ??????????? ????4k??8k????��??��???
 *
 *  ??? 26us ~ 36 us
 */
//uint8_t BBB=0;
//uint8_t CCC=0;
void ir_detect_capture(void)
{
    uint8_t state;
    uint8_t index = 0;

   if(get_ir_enable_flag() == 1)
   {
       return;
   }
	
    for (index = 0; index < IR_POSITION_MAX; index++)
    {
        if (0xff == ir_io_table[index].pin)
        {
            continue;
        }
        state = GPIO_Input_Pin_Data_Get(GPIOA ,GPIO_PIN_11 );
        //????????????? 0 ?? 1 ????
        state ^= IS_LEVEL_INVERT;				
        //��??????????
        ir_working_byte[index] <<= 1;
        ir_working_byte[index] |= state;
        ir_capture_counter[index]++;
        if (ir_capture_counter[index] >= 8)
        {
            if (!ir_rx_q_check_is_full(index))
            {
                ir_rx_q_put(index, ir_working_byte[index]);
                ir_working_byte[index] = index;
                ir_capture_counter[index] = 0;
            }
        }
     }
}


/**
 * @fn void ir_decoder_io_level_init(void)
 * @brief ??????????��????
 *
 */
void ir_decoder_io_level_init(void)
{
    for(uint8_t i = 0; i < IR_POSITION_MAX; i++)
    {
        ir_working_byte[i] = 0;
        ir_capture_counter[i] = 0;

        ir_rx_queue[i].data_buffer = &(ir_rx_buffer[i][0]);
        ir_rx_queue[i].queue_len = IR_QUEUE_LEN;
        ir_rx_queue[i].read_ptr = 0;
        ir_rx_queue[i].write_ptr = 0;
        ir_rx_queue[i].is_lock_irq = 0;

        ir_dock_decode_init(i);        
    }
}

//#endif
